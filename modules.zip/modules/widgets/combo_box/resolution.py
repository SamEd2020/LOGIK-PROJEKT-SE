#
# DEVELOPMENT
# -------------------------------------------------------------------------- #

# DISCLAIMER:       This file is part of LOGIK-PROJEKT.
#                   Copyright Strength In Numbers © 2025
               
#                   LOGIK-PROJEKT creates directories, files, scripts & tools
#                   for use with Autodesk Flame and other software.

#                   LOGIK-PROJEKT is free software.

#                   You can redistribute it and/or modify it under the terms
#                   of the GNU General Public License as published by the
#                   Free Software Foundation, either version 3 of the License,
#                   or any later version.

#                   This program is distributed in the hope that it will be
#                   useful, but WITHOUT ANY WARRANTY; without even the
#                   implied warranty of MERCHANTABILITY or FITNESS FOR A
#                   PARTICULAR PURPOSE.

#                   See the GNU General Public License for more details.

#                   You should have received a copy of the GNU General
#                   Public License along with this program.

#                   If not, see <https://www.gnu.org/licenses/>.
               
#                   Contact: phil_man@mac.com

# -------------------------------------------------------------------------- #

# File Name:        resolution.py
# Version:          2.0.0
# Created:          2024-01-19
# Modified:         2024-12-31

# ========================================================================== #
# This section defines the import statements and directory paths.
# ========================================================================== #

# Standard library imports
import argparse
import ast
import base64
import collections
import datetime
import getpass
import grp
import importlib
import io
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import unittest
import xml

# -------------------------------------------------------------------------- #

def get_base_path():
    if getattr(sys, 'frozen', False):
        return sys._MEIPASS
    else:
        return os.path.abspath(
            os.path.join(
                os.path.dirname(__file__), '..', '..', '..'
            )
        )
   
# -------------------------------------------------------------------------- #

def get_resource_path(relative_path):
    base_path = get_base_path()
    return os.path.join(
        base_path,
        relative_path
    )

# -------------------------------------------------------------------------- #

# Set the path to the 'modules' directory
modules_dir = get_resource_path('modules')

# Set the path to the 'resources' directory
resources_dir = get_resource_path('resources')

# Append the modules path to the system path
if modules_dir not in sys.path:
    sys.path.append(modules_dir)

# ========================================================================== #
# This section defines third party imports.
# ========================================================================== #

# Third-Party imports
from PySide6.QtCore import Signal
from PySide6.QtWidgets import QComboBox

from modules.widgets.combo_box.items_resolution import combine_resolutions

# ========================================================================== #
# This section defines environment specific variables.
# ========================================================================== #

# These paths should be passed from the main app.
the_hostname = "delta"
the_projekt_os = "Linux"
the_software_version = "flame_2025.1.pr199"
the_sanitized_version = "2025_1"
the_framestore = "stonefs"

'''
Print the variables for debugging
print(f"  Debug: the_hostname:              {the_hostname}")
print(f"  Debug: the_projekt_os:            {the_projekt_os}")
print(f"  Debug: the_software_version:      {the_software_version}")
print(f"  Debug: the_sanitized_version:     {the_sanitized_version}")
'''

# ========================================================================== #
# This section defines common paths.
# ========================================================================== #

projekt_roots_config_path = os.path.join(
    resources_dir,
    'cfg',
    'projekt_configuration',
    'roots',
    'projekt_roots.json'
)

# Read the JSON configuration file
try:
    with open(projekt_roots_config_path, 'r') as config_file:
        config = json.load(config_file)
except Exception as e:
    print(f"  Error reading JSON configuration file: {e}")
    config = {}

# Define common directory paths
the_projekts_dir = config.get(
    'the_projekts_dir',
    "/PROJEKTS"
)

the_projekt_flame_dirs = config.get(
    'the_projekt_flame_dirs',
    "/opt/Autodesk/project"
)

the_adsk_dir = config.get(
    'the_adsk_dir',
    "/opt/Autodesk"
)

the_adsk_dir_linux = config.get(
    'the_adsk_dir_linux',
    "/opt/Autodesk"
)

the_adsk_dir_macos = config.get(
    'the_adsk_dir_macos',
    "/Applications/Autodesk"
)

'''
Print the variables for debugging
print(f"  Debug: projekt_roots_config_path: {projekt_roots_config_path}")
print(f"  Debug: the_projekts_dir:          {the_projekts_dir}")
print(f"  Debug: the_projekt_flame_dirs:    {the_projekt_flame_dirs}")
print(f"  Debug: the_adsk_dir:              {the_adsk_dir}")
print(f"  Debug: the_adsk_dir_linux:        {the_adsk_dir_linux}")
print(f"  Debug: the_adsk_dir_macos:        {the_adsk_dir_macos}")
'''

# ========================================================================== #
# This section defines projekt specific paths.
# ========================================================================== #

# These paths should be passed from the main app.
the_projekt_name = "8888_new_job"
the_projekt_flame_name = f"{the_projekt_name}_{the_sanitized_version}_{the_hostname}"

separator = '# ' + '-' * 75 + ' #'

the_projekt_dir = f"{the_projekts_dir}/{the_projekt_name}"
the_projekt_flame_dir = f"{the_projekt_flame_dirs}/{the_projekt_flame_name}"

# ========================================================================== #
# This section defines the primary functions for the script.
# ========================================================================== #

class WidgetResolution(QComboBox):
    resolution_changed = Signal(dict)  # Signal to emit resolution details

    def __init__(self, parent=None):
        super().__init__(parent)
       
        # Set object name if needed
        self.setObjectName("template_resolution")

        # Base directory path
        base_dir = os.path.dirname(os.path.abspath(__file__))

        # Directory and order file paths
        directory = os.path.join(base_dir, '..', '..', '..', 'resources', 'cfg', 'projekt_configuration', 'parameters', "resolution_json_files")
        order_file = os.path.join(base_dir, '..', '..', '..', 'resources', 'cfg', 'projekt_configuration', 'parameters', "load_order", "load_order_resolution.json")

        combobox_items, self.resolution_details = combine_resolutions(directory, order_file)

        for item in combobox_items:
            if item['type'] == 'separator':
                self.addItem(item['name'])  # Add separator as normal item (adjust if needed)
            else:
                self.addItem(item['name'])

        # Set default properties
        self.setCurrentText(self.get_default_resolution())
        self.setEditable(False)

        # Connect signal to slot
        self.currentIndexChanged.connect(self.emit_resolution_details)

    def emit_resolution_details(self):
        current_text = self.currentText()
        resolution_detail = next((detail for detail in self.resolution_details if detail['resolution_name'] == current_text), None)
        if resolution_detail:
            self.resolution_changed.emit(resolution_detail)  # Emit entire resolution detail dictionary

    def get_widget_parameters(self):
        widget_parameters = {
            "widget_name": "template_resolution",
            "widget_type": "QComboBox",
            "widget_label_name": "Resolution: ",
            "widget_default_value": self.get_default_resolution(),
            "widget_placeholder_value": "",
            "widget_item_values": "items_resolution.py",
            "widget_read_only": False
        }
        return widget_parameters

    def get_default_resolution(self):
        """
        Reads the JSON file and returns the default bit depth.
        """
        json_file_path = get_resource_path(
            'resources/cfg/projekt_configuration/parameters/default_parameters.json'
        )
       
        try:
            with open(json_file_path, 'r') as file:
                data = json.load(file)
            resolution = data.get("Resolution: ")
            return resolution
        except:
            # Return a default value in case of an error
            return "1920 x 1080 | HD 1080 16:9"

# ========================================================================== #
# 53 54 52 45 4E 47 54 48 2D 49 4E 2D 4E 55 4D 42 45 52 53 C2 A9 32 30 32 35 #
# ========================================================================== #

# Changelist:      

# -------------------------------------------------------------------------- #
# version:          0.0.1
# created:          2024-01-19 - 12:34:56
# comments:         scripts to create flame projekts, presets & templates.
# -------------------------------------------------------------------------- #
# version:          0.1.0
# modified:         2024-04-20 - 16:20:00
# comments:         refactored monolithic program into separate functions.
# -------------------------------------------------------------------------- #
# version:          0.5.0
# modified:         2024-05-24 - 20:24:00
# comments:         merged flame_colortoolkit with projekt.
# -------------------------------------------------------------------------- #
# version:          0.6.0
# modified:         2024-05-25 - 15:00:03
# comments:         started conversion to python3.
# -------------------------------------------------------------------------- #
# version:          0.7.0
# modified:         2024-06-21 - 18:21:03
# comments:         started gui design with pyside6.
# -------------------------------------------------------------------------- #
# version:          0.9.9
# modified:         2024-08-31 - 16:51:09
# comments:         prep for release - code appears to be functional
# -------------------------------------------------------------------------- #
# version:          1.9.9
# modified:         2024-12-25 - 09:50:16
# comments:         Preparation for future features
# -------------------------------------------------------------------------- #
# version:          2.0.0
# modified:         2024-12-31 - 10:35:41
# comments:         Improved legibility and minor modifications
# -------------------------------------------------------------------------- #
